import React, { useState, useEffect } from 'react';

const API_PRODUCTS = 'http://localhost:5000/api/products';
const API_ORDERS = 'http://localhost:5000/api/orders';

export default function Storefront() {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  
  const [customer, setCustomer] = useState({
    name: '', phone: '', address: '', city: 'Karianwala'
  });

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await fetch(API_PRODUCTS);
      if (res.ok) {
        const data = await res.json();
        setProducts(data);
        setFilteredProducts(data);
      }
    } catch (err) {
      console.log("Error fetching products:", err);
    }
  };

  const addToCart = (product) => {
    const existing = cart.find(item => item.name === product.name);
    if (existing) {
      setCart(cart.map(item => item.name === product.name ? { ...item, qty: item.qty + 1 } : item));
    } else {
      setCart([...cart, { name: product.name, price: product.price, qty: 1 }]);
    }
  };

  const removeFromCart = (name) => {
    setCart(cart.filter(item => item.name !== name));
  };

  const cartTotal = cart.reduce((acc, item) => acc + (item.price * item.qty), 0);

  const handleOrderSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(API_ORDERS, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: customer.name,
          customerPhone: customer.phone,
          customerAddress: customer.address,
          city: customer.city,
          items: cart,
          totalAmount: cartTotal
        })
      });
      if (res.ok) {
        alert("🎉 Order placed successfully!");
        setCart([]);
        setIsCheckoutOpen(false);
      }
    } catch (err) {
      alert("❌ Failed to place order");
    }
  };

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800">
      {/* Header */}
      <header className="bg-white sticky top-0 z-40 shadow-sm border-b p-4 flex justify-between items-center max-w-7xl mx-auto">
        <h1 className="text-xl font-black text-emerald-900">TABARAK MEGA MALL</h1>
        <button onClick={() => setIsCartOpen(true)} className="bg-emerald-50 text-emerald-800 px-4 py-2 rounded-full font-bold">
          🛒 Cart ({cart.reduce((a, b) => a + b.qty, 0)})
        </button>
      </header>

      {/* Catalog */}
      <main className="max-w-7xl mx-auto p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {filteredProducts.map(p => (
            <div key={p._id} className="bg-white p-4 rounded-2xl shadow-sm border flex flex-col justify-between">
              <div>
                <img src={p.image} alt={p.name} className="h-40 w-full object-cover rounded-xl mb-3" />
                <h3 className="font-bold">{p.name}</h3>
                <p className="text-emerald-800 font-black">Rs. {p.price}</p>
              </div>
              <button onClick={() => addToCart(p)} className="mt-4 bg-slate-100 hover:bg-slate-200 py-2 rounded-xl font-bold text-xs">
                + Add to Cart
              </button>
            </div>
          ))}
        </div>
      </main>

      {/* Cart Modal */}
      {isCartOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex justify-end">
          <div className="bg-white w-full max-w-md h-full p-6 flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-center border-b pb-4 mb-4">
                <h3 className="font-bold text-lg">Your Cart</h3>
                <button onClick={() => setIsCartOpen(false)} className="text-xl font-bold">&times;</button>
              </div>
              {cart.map(item => (
                <div key={item.name} className="flex justify-between items-center bg-slate-50 p-3 rounded-xl mb-2">
                  <div>
                    <p className="font-bold text-sm">{item.name}</p>
                    <p className="text-xs text-slate-500">Rs. {item.price} x {item.qty}</p>
                  </div>
                  <button onClick={() => removeFromCart(item.name)} className="text-rose-500 font-bold">&times;</button>
                </div>
              ))}
            </div>
            <div className="border-t pt-4">
              <div className="flex justify-between font-black mb-4">
                <span>Total:</span>
                <span className="text-emerald-700">Rs. {cartTotal}</span>
              </div>
              <button onClick={() => { setIsCartOpen(false); setIsCheckoutOpen(true); }} className="w-full bg-slate-900 text-white py-3 rounded-xl font-bold text-xs mb-2">
                Checkout Online
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}